import { del, get, post, put } from "./api.js";

    export async function getAll() {
        return await get("/data/albums?sortBy=_createdOn%20desc")
    }

export async function getById(id) {
     return await get(`/data/albums/${id}`) 
}

export async function deleteById(id) {
     return await del(`/data/albums/${id}`)
}

export async function create(data) {
    return await post("/data/albums", data)
}

export async function editById(id, data) {
     return await put(`/data/albums/${id}`, data)
}
// if myposts needed, add function